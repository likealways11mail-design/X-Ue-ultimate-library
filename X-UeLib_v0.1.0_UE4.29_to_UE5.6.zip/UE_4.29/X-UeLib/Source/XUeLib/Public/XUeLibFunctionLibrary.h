#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "XUeLibFunctionLibrary.generated.h"

/**
 * Foundational Blueprint utilities for X-UeLib.
 * Additional functions are added incrementally by category.
 */
UCLASS()
class XUELIB_API UXUeLibFunctionLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()

public:

    /** Returns true when two floats are equal within the supplied tolerance. */
    UFUNCTION(BlueprintPure, Category="X-UeLib|01 General Utility")
    static bool NearlyEqualFloat(float A, float B, float Tolerance = KINDA_SMALL_NUMBER);

    /** Remaps a value from one range to another, with optional clamping. */
    UFUNCTION(BlueprintPure, Category="X-UeLib|01 General Utility")
    static float RemapFloat(float Value, float InMin, float InMax, float OutMin, float OutMax, bool bClamp = false);

    /** Normalizes an angle to the -180..180 range. */
    UFUNCTION(BlueprintPure, Category="X-UeLib|06 Rotation")
    static float NormalizeAngle180(float Angle);

    /** Returns true if an object reference is valid. */
    UFUNCTION(BlueprintPure, Category="X-UeLib|19 Validation")
    static bool IsObjectValid(const UObject* Object);
};
