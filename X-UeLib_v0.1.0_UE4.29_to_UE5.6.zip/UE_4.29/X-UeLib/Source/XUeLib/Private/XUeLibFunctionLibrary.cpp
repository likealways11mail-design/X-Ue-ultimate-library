#include "XUeLibFunctionLibrary.h"

bool UXUeLibFunctionLibrary::NearlyEqualFloat(float A, float B, float Tolerance)
{
    return FMath::IsNearlyEqual(A, B, Tolerance);
}

float UXUeLibFunctionLibrary::RemapFloat(float Value, float InMin, float InMax, float OutMin, float OutMax, bool bClamp)
{
    if (FMath::IsNearlyEqual(InMin, InMax))
    {
        return OutMin;
    }

    const float Alpha = (Value - InMin) / (InMax - InMin);
    const float FinalAlpha = bClamp ? FMath::Clamp(Alpha, 0.0f, 1.0f) : Alpha;
    return FMath::Lerp(OutMin, OutMax, FinalAlpha);
}

float UXUeLibFunctionLibrary::NormalizeAngle180(float Angle)
{
    return FMath::UnwindDegrees(Angle);
}

bool UXUeLibFunctionLibrary::IsObjectValid(const UObject* Object)
{
    return IsValid(Object);
}
