#include "XUeLibFunctionLibrary.h"
#include "Engine/World.h"
bool UXUeLibFunctionLibrary::NearlyEqualFloat(float A,float B,float T){return FMath::IsNearlyEqual(A,B,FMath::Max(0.f,T));}
float UXUeLibFunctionLibrary::RemapFloat(float V,float I0,float I1,float O0,float O1,bool C){if(FMath::IsNearlyEqual(I0,I1))return O0;float A=(V-I0)/(I1-I0);return FMath::Lerp(O0,O1,C?FMath::Clamp(A,0.f,1.f):A);}
float UXUeLibFunctionLibrary::QuantizeFloat(float V,float S){return FMath::IsNearlyZero(S)?V:FMath::RoundToFloat(V/S)*S;}
float UXUeLibFunctionLibrary::SafeDivideFloat(float N,float D,float Def){return FMath::IsNearlyZero(D)?Def:N/D;}
FTransform UXUeLibFunctionLibrary::TransformDelta(const FTransform&A,const FTransform&B){return B.GetRelativeTransform(A);}
FTransform UXUeLibFunctionLibrary::InterpolateTransform(const FTransform&A,const FTransform&B,float Alpha){FTransform R;R.Blend(A,B,FMath::Clamp(Alpha,0.f,1.f));return R;}
float UXUeLibFunctionLibrary::VectorAngleDegrees(FVector A,FVector B){return FMath::RadiansToDegrees(FMath::Acos(FMath::Clamp(A.GetSafeNormal()|B.GetSafeNormal(),-1.f,1.f)));}
FVector UXUeLibFunctionLibrary::ProjectVectorOnPlane(FVector V,FVector N){return FVector::VectorPlaneProject(V,N.GetSafeNormal());}
FVector UXUeLibFunctionLibrary::DirectionBetween(FVector A,FVector B){return (B-A).GetSafeNormal();}
FVector UXUeLibFunctionLibrary::ClosestPointOnSegment(FVector P,FVector A,FVector B){return FMath::ClosestPointOnSegment(P,A,B);}
float UXUeLibFunctionLibrary::NormalizeAngle180(float A){return FMath::UnwindDegrees(A);}
float UXUeLibFunctionLibrary::SignedAngleDelta(float A,float B){return FMath::FindDeltaAngleDegrees(A,B);}
FRotator UXUeLibFunctionLibrary::LookAtRotation(FVector A,FVector B,FVector U){FVector D=(B-A).GetSafeNormal();return D.IsNearlyZero()?FRotator::ZeroRotator:FRotationMatrix::MakeFromXZ(D,U).Rotator();}
float UXUeLibFunctionLibrary::NormalizeTime(float T,float D){return D<=KINDA_SMALL_NUMBER?0.f:FMath::Clamp(T/D,0.f,1.f);}
float UXUeLibFunctionLibrary::PingPongTime(float T,float L){return L<=KINDA_SMALL_NUMBER?0.f:FMath::Abs(FMath::Fmod(T,L*2.f)-L);}
bool UXUeLibFunctionLibrary::IsWithinDistance(FVector A,FVector B,float D){return FVector::DistSquared(A,B)<=FMath::Square(FMath::Max(0.f,D));}
bool UXUeLibFunctionLibrary::IsFacingTarget(FVector O,FRotator R,FVector T,float H){FVector D=(T-O).GetSafeNormal();return !D.IsNearlyZero()&&FMath::RadiansToDegrees(FMath::Acos(FMath::Clamp(R.Vector()|D,-1.f,1.f)))<=FMath::Max(0.f,H);}
bool UXUeLibFunctionLibrary::IsObjectValid(const UObject* O){return IsValid(O);}
bool UXUeLibFunctionLibrary::IsVectorFinite(FVector V){return FMath::IsFinite(V.X)&&FMath::IsFinite(V.Y)&&FMath::IsFinite(V.Z);}
bool UXUeLibFunctionLibrary::IsGameWorld(const UObject* O){const UWorld*W=O?O->GetWorld():nullptr;return W&&(W->WorldType==EWorldType::Game||W->WorldType==EWorldType::PIE);}
bool UXUeLibFunctionLibrary::IsAuthority(const UObject* O){const UWorld*W=O?O->GetWorld():nullptr;return W&&W->GetNetMode()!=NM_Client;}
float UXUeLibFunctionLibrary::SurfaceSlopeDegrees(FVector N){return FMath::RadiansToDegrees(FMath::Acos(FMath::Clamp(N.GetSafeNormal()|FVector::UpVector,-1.f,1.f)));}
bool UXUeLibFunctionLibrary::IsPointInsideSphere(FVector P,FVector C,float R){return FVector::DistSquared(P,C)<=FMath::Square(FMath::Max(0.f,R));}
float UXUeLibFunctionLibrary::SmoothStep(float A){float T=FMath::Clamp(A,0.f,1.f);return T*T*(3.f-2.f*T);}
FVector UXUeLibFunctionLibrary::SpringLikeVector(FVector C,FVector T,FVector&V,float S,float D,float Dt){Dt=FMath::Max(0.f,Dt);V+=((T-C)*FMath::Max(0.f,S)-V*FMath::Max(0.f,D))*Dt;return C+V*Dt;}
bool UXUeLibFunctionLibrary::HasFloatChanged(float A,float B,float T){return !FMath::IsNearlyEqual(A,B,FMath::Max(0.f,T));}
bool UXUeLibFunctionLibrary::NearlyEqualVector(FVector A,FVector B,float T){return A.Equals(B,FMath::Max(0.f,T));}
FVector UXUeLibFunctionLibrary::RandomPointInBox(FVector C,FVector E,int32 Seed){FRandomStream S(Seed);E=E.GetAbs();return C+FVector(S.FRandRange(-E.X,E.X),S.FRandRange(-E.Y,E.Y),S.FRandRange(-E.Z,E.Z));}
int32 UXUeLibFunctionLibrary::WeightedRandomIndex(const TArray<float>&W,int32 Seed){float Total=0;for(float X:W)Total+=FMath::Max(0.f,X);if(Total<=KINDA_SMALL_NUMBER)return INDEX_NONE;FRandomStream S(Seed);float P=S.FRandRange(0.f,Total);for(int32 I=0;I<W.Num();++I){P-=FMath::Max(0.f,W[I]);if(P<=0)return I;}return W.Num()-1;}
