#include "Modules/ModuleManager.h"

class FXUeLibModule : public IModuleInterface
{
public:
    virtual void StartupModule() override {}
    virtual void ShutdownModule() override {}
};

IMPLEMENT_MODULE(FXUeLibModule, XUeLib)
