#pragma once
#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "XUeLibFunctionLibrary.generated.h"

UCLASS()
class XUELIB_API UXUeLibFunctionLibrary : public UBlueprintFunctionLibrary
{
    GENERATED_BODY()
public:
    UFUNCTION(BlueprintPure, Category="X-UeLib|01 General Utility") static bool NearlyEqualFloat(float A,float B,float Tolerance=KINDA_SMALL_NUMBER);
    UFUNCTION(BlueprintPure, Category="X-UeLib|01 General Utility") static float RemapFloat(float Value,float InMin,float InMax,float OutMin,float OutMax,bool bClamp=false);
    UFUNCTION(BlueprintPure, Category="X-UeLib|01 General Utility") static float QuantizeFloat(float Value,float Step);
    UFUNCTION(BlueprintPure, Category="X-UeLib|01 General Utility") static float SafeDivideFloat(float Numerator,float Denominator,float DefaultValue=0.f);
    UFUNCTION(BlueprintPure, Category="X-UeLib|04 Transform Spatial") static FTransform TransformDelta(const FTransform& A,const FTransform& B);
    UFUNCTION(BlueprintPure, Category="X-UeLib|04 Transform Spatial") static FTransform InterpolateTransform(const FTransform& A,const FTransform& B,float Alpha);
    UFUNCTION(BlueprintPure, Category="X-UeLib|05 Vector Math") static float VectorAngleDegrees(FVector A,FVector B);
    UFUNCTION(BlueprintPure, Category="X-UeLib|05 Vector Math") static FVector ProjectVectorOnPlane(FVector Vector,FVector PlaneNormal);
    UFUNCTION(BlueprintPure, Category="X-UeLib|05 Vector Math") static FVector DirectionBetween(FVector From,FVector To);
    UFUNCTION(BlueprintPure, Category="X-UeLib|05 Vector Math") static FVector ClosestPointOnSegment(FVector Point,FVector Start,FVector End);
    UFUNCTION(BlueprintPure, Category="X-UeLib|06 Rotation") static float NormalizeAngle180(float Angle);
    UFUNCTION(BlueprintPure, Category="X-UeLib|06 Rotation") static float SignedAngleDelta(float From,float To);
    UFUNCTION(BlueprintPure, Category="X-UeLib|06 Rotation") static FRotator LookAtRotation(FVector From,FVector To,FVector UpVector=FVector::UpVector);
    UFUNCTION(BlueprintPure, Category="X-UeLib|10 Time") static float NormalizeTime(float CurrentTime,float Duration);
    UFUNCTION(BlueprintPure, Category="X-UeLib|10 Time") static float PingPongTime(float Time,float Length);
    UFUNCTION(BlueprintPure, Category="X-UeLib|13 Gameplay") static bool IsWithinDistance(FVector A,FVector B,float Distance);
    UFUNCTION(BlueprintPure, Category="X-UeLib|13 Gameplay") static bool IsFacingTarget(FVector Origin,FRotator Rotation,FVector Target,float HalfAngleDegrees);
    UFUNCTION(BlueprintPure, Category="X-UeLib|19 Validation") static bool IsObjectValid(const UObject* Object);
    UFUNCTION(BlueprintPure, Category="X-UeLib|19 Validation") static bool IsVectorFinite(FVector Vector);
    UFUNCTION(BlueprintPure, Category="X-UeLib|25 World") static bool IsGameWorld(const UObject* WorldContextObject);
    UFUNCTION(BlueprintPure, Category="X-UeLib|26 Networking") static bool IsAuthority(const UObject* WorldContextObject);
    UFUNCTION(BlueprintPure, Category="X-UeLib|31 Surface") static float SurfaceSlopeDegrees(FVector SurfaceNormal);
    UFUNCTION(BlueprintPure, Category="X-UeLib|32 Geometry") static bool IsPointInsideSphere(FVector Point,FVector Center,float Radius);
    UFUNCTION(BlueprintPure, Category="X-UeLib|33 Interpolation Motion") static float SmoothStep(float Alpha);
    UFUNCTION(BlueprintPure, Category="X-UeLib|33 Interpolation Motion") static FVector SpringLikeVector(FVector Current,FVector Target,FVector& Velocity,float Stiffness,float Damping,float DeltaTime);
    UFUNCTION(BlueprintPure, Category="X-UeLib|41 Change Detection") static bool HasFloatChanged(float Previous,float Current,float Tolerance=KINDA_SMALL_NUMBER);
    UFUNCTION(BlueprintPure, Category="X-UeLib|43 Comparison") static bool NearlyEqualVector(FVector A,FVector B,float Tolerance=KINDA_SMALL_NUMBER);
    UFUNCTION(BlueprintPure, Category="X-UeLib|34 Procedural Generation") static FVector RandomPointInBox(FVector Center,FVector Extent,int32 Seed);
    UFUNCTION(BlueprintPure, Category="X-UeLib|35 Weighted Selection") static int32 WeightedRandomIndex(const TArray<float>& Weights,int32 Seed);
};
