# X-UeLib

UE4.27 generic reusable library plugin for Functions, Macros, and Blueprint Nodes.

## Version
0.1.0 — Foundation / Architecture

## Validated scope
X-UeLib contains 45 utility categories:

- 01. GeneralUtility
- 02. FlowExecution
- 03. ActorComponent
- 04. TransformSpatial
- 05. VectorMath
- 06. Rotation
- 07. StringNameText
- 08. DataStruct
- 09. DebugDevelopment
- 10. Time
- 11. StateLogic
- 12. EventsDelegates
- 13. Gameplay
- 14. AIPerception
- 15. Physics
- 16. DataStructures
- 17. Arrays
- 18. MapsSets
- 19. Validation
- 20. SoftReferences
- 21. Assets
- 22. ReflectionClasses
- 23. Interfaces
- 24. Objects
- 25. World
- 26. Networking
- 27. PlayersControllers
- 28. Camera
- 29. ScreenUI
- 30. CollisionTrace
- 31. Surface
- 32. Geometry
- 33. InterpolationMotion
- 34. ProceduralGeneration
- 35. WeightedSelection
- 36. Tags
- 37. GameplayTags
- 38. LoggingDiagnostics
- 39. Performance
- 40. RuntimeHistory
- 41. ChangeDetection
- 42. Constraints
- 43. Comparison
- 44. PoolingResources
- 45. StateMachines

## Blueprint Node Classification
- Pure Function
- Impure Function
- Macro
- Exec Node
- Async Node
- Latent Node
- Debug Node
- Conversion Node
- Validation Node
- Query Node
- Generator Node

## Architecture
The plugin is intentionally generic and has no dependency on the other X-series plugins.
Each category has a dedicated content/library directory so utilities can be added incrementally.

## Initial implemented nodes
- Nearly Equal Float
- Remap Float
- Normalize Angle 180
- Is Object Valid

These are foundation examples only. The 45-category catalog is prepared for progressive implementation.
