# 12 — EventsDelegates

Reserved for X-UeLib utilities in this category. Implementations should remain generic and reusable across UE4.27 projects.
